#!/bin/bash
if [ "$1" = "init" ]; then

    if [ -f "minitwit.db" ]; then 
        echo "Database already exists."
        exit 1
    fi
    echo "Putting a database to minitwit.db..."
    python3 -c"from minitwit import init_db;init_db()"
elif [ "$1" = "startprod" ]; then
     echo "Starting minitwit with production webserver..."
     nohup "$HOME"/.local/bin/gunicorn --workers 4 --timeout 120 --bind 0.0.0.0:5000 minitwit:app > /tmp/out.log 2>&1 &
elif [ "$1" = "start" ]; then
    echo "Starting minitwit..."
    nohup python3 minitwit.py > /tmp/out.log 2>&1 &

    URL="http://localhost:5000"

    if command -v xdg-open > /dev/null; then
    xdg-open "$URL"    # Linux
    elif command -v open > /dev/null; then
    open "$URL"        # macOS
    else
    explorer.exe "$URL" # Windows
    fi
    
elif [ "$1" = "stop" ]; then
    echo "Stopping minitwit..."
    pkill -f minitwit
elif [ "$1" = "inspectdb" ]; then
    ./flag_tool -i | less
elif [ "$1" = "flag" ]; then
    ./flag_tool "$@"
else
  echo "I do not know this command..."
fi

